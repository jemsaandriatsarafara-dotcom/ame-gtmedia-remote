# GTMedia V7 S5X Remote — LeTV X620

Remote control APK ho an'ny GTMedia V7 S5X, manokana ho an'ny LeTV X620.

## Rafitra ny Project

```
app/
  src/main/
    java/com/example/letvremote/
      MainActivity.kt
    res/layout/
      activity_main.xml
    AndroidManifest.xml
  build.gradle
build.gradle          (copy avy amin'ny build.gradle.root)
settings.gradle
gradlew
.github/workflows/
  build.yml
```

## Fomba fampiasana

1. Alatsaho ireto rakitra rehetra eto GitHub
2. GitHub Actions hamorona APK automatika
3. Alao ny APK ao amin'ny **Actions → Artifacts**
